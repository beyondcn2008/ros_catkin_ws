four_wheel_steering_msgs
==============

ROS messages for vehicles using four wheel steering.
