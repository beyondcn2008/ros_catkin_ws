^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package four_wheel_steering_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2017-04-26)
------------------
* Update url path
* Initial commit from https://github.com/Romea/romea_controllers
* Contributors: Vincent Rousseau
